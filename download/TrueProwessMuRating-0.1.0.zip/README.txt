==============================================================
  TRUE PROWESS MU RATING - the in-game mod
  Version 0.1.0
==============================================================

This is the half that draws the badge in TEKKEN 8. It shows
nothing on its own: the helper (trhmu.exe) is what reads Wavu
Wank and feeds it the numbers. You need both.


--------------------------------------------------------------
  INSTALLING
--------------------------------------------------------------

Copy all three files:

  A_TrueProwessMuRating_1000_P.pak
  A_TrueProwessMuRating_1000_P.ucas
  A_TrueProwessMuRating_1000_P.utoc

into:

  ...\steamapps\common\TEKKEN 8\Polaris\Content\Paks\Mods\

A folder of their own under Mods is fine, and is how it is
installed here:

  ...\Content\Paks\Mods\MuRating\

Make the folders if they are not there. Keep all three files
together and do not rename them: the game needs all three, and
the name is part of how it loads them.

On the Tekken Resource Hub Mod Manager, drop them in and it
handles the rest.


--------------------------------------------------------------
  UNINSTALLING
--------------------------------------------------------------

Delete the three files. Nothing else is touched; the mod only
reads, and it writes nothing to your game.


--------------------------------------------------------------
  HELP
--------------------------------------------------------------

Join the Discord, find the Mu support thread, and file a ticket:

  https://discord.com/invite/DmPqYPtgKg

In the helper, Settings > Troubleshooting > Open Mod Folder says
whether the game can actually see this mod, and Diagnostics
copies a report worth pasting with your ticket.


--------------------------------------------------------------
  DISCLAIMER
--------------------------------------------------------------

This is a free community tool. Ratings come from Wavu Wank
(https://wank.wavu.wiki) by 6weetbix. Not affiliated with, or
endorsed by, Bandai Namco Entertainment or Wavu Wank. Use it at
your own risk.
