==============================================================
  TEKKEN RESOURCE HUB MU RATING HUD
  Version 0.1.0
==============================================================

Your Wavu Wank Mu Rating in TEKKEN 8: on the badge in game, the
change after each fight, and your opponents' ratings in the
replay menu.

It is two pieces. A mod that draws the badge, and this helper,
which keeps the badge fed. You need both.


--------------------------------------------------------------
  INSTALLING THE MOD
--------------------------------------------------------------

Copy all three mod files into your game's mod folder:

  A_MuRating_1000_P.pak
  A_MuRating_1000_P.ucas
  A_MuRating_1000_P.utoc

  ...\steamapps\common\TEKKEN 8\Polaris\Content\Paks\Mods\

Make the Mods folder if it is not there already. Keep all three
together and do not rename them. On the Tekken Resource Hub Mod
Manager, just drop them in.


--------------------------------------------------------------
  RUNNING THE HELPER
--------------------------------------------------------------

1. Extract this folder anywhere you like.
2. Run trhmu.exe

There is no installer and nothing else to download. Nothing is
written to the registry unless you turn on Start with Windows.

Windows will show a blue "Windows protected your PC" warning the
first time. That is because the app is not code signed yet, not
because anything is wrong with it. Click "More info", then
"Run anyway".


--------------------------------------------------------------
  FIRST RUN
--------------------------------------------------------------

Enter your Tekken ID, the same code the game's Replay menu shows
you. It looks like 4Rh7-ai3D-3G2a.

The helper reads your Wavu Wank page once, pairs that ID to the
Steam account you are signed in with, and connects on its own
from then on. Start TEKKEN 8 and the helper opens with it; your
MR sits beside your rank.

You can save up to five accounts, so alts and a rival's ID are
one click away.


--------------------------------------------------------------
  IF THE BADGE DOES NOT SHOW
--------------------------------------------------------------

Settings > Troubleshooting > Open Mod Folder says whether the
game can actually see the mod, and opens the folder it belongs
in. That is the usual cause.

Nothing draws over exclusive Fullscreen, in any app. For the
notification cards, use Borderless or Windowed.


--------------------------------------------------------------
  REQUIREMENTS
--------------------------------------------------------------

  Windows 10 or later
  TEKKEN 8 on Steam
  Microsoft Edge WebView2 (already on almost every Windows PC)


--------------------------------------------------------------
  HELP
--------------------------------------------------------------

Join the Discord, find the Mu support thread, and file a ticket:

  https://discord.com/invite/DmPqYPtgKg

Attach your diagnostics. Settings > Troubleshooting >
Diagnostics copies a report of the app, game, mods, connection,
MR and recent log. Pasting that with your ticket is the
difference between a guess and a fix.

  https://tekkenresourcehub.com
  https://ko-fi.com/trh


--------------------------------------------------------------
  DISCLAIMER
--------------------------------------------------------------

This is a free community tool. Ratings come from Wavu Wank
(https://wank.wavu.wiki) by 6weetbix. Not affiliated with, or
endorsed by, Bandai Namco Entertainment or Wavu Wank. Use it at
your own risk.
